# Base de datos

Aqui podrás ver las bases de datos que usamos.

Contamos con cuatro distintos archivos. En cada uno de ellos se encuentran los datos para México y los 32 estados, del 28 de febrero del 2020 hasta el 19 de febrero del 2020.

**Actualizaremos las bases de datos a diario, pero solo lo haremos cuando el día haya terminado. Esto para evitar que ciertos eventos sean omitidos.**

Las bases de datos que encontrarás aquí son:
- Casos totales en México y los 32 estados;
- Casos activos en México y los 32 estados;
- Muertes en México y los 32 estados;
- Recuperaciones en México y los 32 estados.
